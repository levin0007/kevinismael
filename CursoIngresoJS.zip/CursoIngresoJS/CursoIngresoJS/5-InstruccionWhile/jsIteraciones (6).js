function mostrar()
{

	var contador=0;
	var acumulador=0;



document.getElementById('suma').value=acumulador;
document.getElementById('promedio').value=acumulador/5;

}//FIN DE LA FUNCIÓN